﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public int Var;
    public static bool startShort = false;
    bool startS = true;
    int open, it = 0;
    bool b = false, flag = false;
    char d;
    bool fg = false;
    public string lastPos;
    public string lastPos2;
    public char dir = 'l';
    readonly float start;
    int count = 0;
    public static string path ="";
    public GameObject slave;
    
    string[] list = { "LBR", "LBS", "RBL", "SBL", "SBS", "LBL" };
    string[] listC = { "B", "R", "B", "R", "B", "S" };
    // Start is called before the first frame update
    void oneStepMovement()
    {  
        moveDir(dir, 0.9f,4);
    }
    
    float leftRay()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    float rightRay()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    float frontRay()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    void drawDir()
    {
        RaycastHit hit=new RaycastHit();
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else hit = new RaycastHit();
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else hit = new RaycastHit();
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else hit = new RaycastHit();
    }
    void changeDirection(char tem)
    {
        dir = tem;
    }
    char setDir(char tem)
    {
        if (tem != 'e')
        {
            if (dir == 'l')
            {
                if (tem == 'l')
                {
                    return 'd';
                }
                else
                {
                    return 'u';
                }
            }
            else if (dir == 'r')
            {
                if (tem == 'l')
                {
                    return 'u';
                }
                else
                {
                    return 'd';
                }
            }
            else if (dir == 'u')
            {
                if (tem == 'l')
                {
                    return 'l';
                }
                else
                {
                    return 'r';
                }
            }
            else if (dir == 'd')
            {
                if (tem == 'l')
                {
                    return 'r';
                }
                else
                {
                    return 'l';
                }
            }
        }
        if (tem == 'e')
        {
            if (dir == 'l')
            {
                return 'r';
            }
            else if (dir == 'r')
            {
                return 'l';
            }
            else if (dir == 'u')
            {
                return 'd';
            }
            else
            {
                return 'u';
            }
        }
        return dir;
    }
    void RegRightOpen()
    {
        if (rightRay() > 6 || rightRay() == 0)
        {
            if(startS)path += 'S';
            if (rightRay() > 6 || rightRay() == 0)
            {
                moveDir(dir, 1f,5);
            }
        }
    }
    void moveDir(char dir, float dis,int spd)
    {

        dis = 0.5f;   
        if (dir == 'l')
        {

            transform.position = Vector3.MoveTowards(transform.position, transform.position - new Vector3(dis, 0f, 0f), 0.3f);

        }
        else if (dir == 'r')
        {

            transform.position = Vector3.MoveTowards(transform.position, transform.position + new Vector3(dis, 0f, 0f), 0.3f);
        }
        else if (dir == 'u')
        {
            transform.position = Vector3.MoveTowards(transform.position, transform.position + new Vector3(0f, 0f, dis), 0.3f);

        }
        else
        {


            transform.position = Vector3.MoveTowards(transform.position, transform.position - new Vector3(0f, 0f, dis), 0.3f);


        }
    }
    
    bool IsGoal()
    {
        if (transform.position.x <= 199 ) { fg = true; return true ; }
        //else return false;
        else
        {
            return false;

        }
    }
    bool CheckAgain(string tem)
    {
        for (int i = 0; i < 6; i++)
        {
            if (tem.IndexOf(list[i]) >= 0)
                return true;
        }
        return false;
    }
    string ReturnC(int i)
    {
        return listC[i];
    }
    void SubPath(string tem1)
    {

        string value = "";

        while (CheckAgain(tem1) == true)
        {
                for (int j = 0; j < 6; j++)
                {
                    if (tem1.IndexOf(list[j])>-1)
                    {
                    tem1 = tem1.Replace(list[j], listC[j]);
                    break;
                    }
                }
            
        }
        path = tem1;
    }
    void moveSlaveToShortesPath()
    {
        
            if(path[it]=='B')
            {
                changeDirection(setDir('e'));
            }
            else if(path[it]=='L')
            {
                if (leftRay() < 6 || leftRay() == 0)
                    moveDir(dir, 1f,5);
                else
                {
                    d = 'l';
                    open = 2;
                    flag = true;
                    b = true;
                }
            }
            else if (path[it] == 'R')
            {
                if (rightRay() < 6 || rightRay() == 0)
                    moveDir(dir, 1f,5);
                else
                {
                    d = 'r';
                    open = 2;
                    flag = true;
                    b = true;
                }
        }
            else if (path[it] == 'S')
            {
                if((rightRay() < 6 || rightRay() == 0) || (leftRay() < 6 || leftRay() == 0))
                {
                    moveDir(dir, 1f,5);
                }
            }
        
    }
    void Start()
    {
        
        
    }

    // Update is called once per frame
    void Update()
    {
        lastPos = path;
        
        drawDir();
        if (flag == true && b == true)
        {
            if (open == 2)
            {
                if (count++ > 10)
                {
                    count = 0;
                    open--;

                }
                oneStepMovement();
            }
            else if (open == 1)
            {
                lastPos2 = transform.position + "";
                if (count == 0)
                    changeDirection(setDir(d));
                if (count++ > 18)
                {
                    count = 0;
                    open--;
                    if (startShort == false)
                        flag = false;
                    if (IsGoal() == true)
                    {
                        
                        b = false;
                        flag = true;
                        lastPos2 = path;
                        
                        SubPath(path);
                        lastPos = path;
                        slave.SetActive(true);
                        

                        startShort = true;
                        //Slave obj = new Slave();

                    }
                }
                oneStepMovement();
            }
        }
        else if (open <= 0)
        {

            open = 0;

        }
        if (flag == false)
        {

                if (leftRay() > 6)
                {
                    d = 'l';
                    open = 2;
                    flag = true;
                    b = true;
                    path += 'L';
                }
                else if (frontRay() > 3)
                {
                if (IsGoal() == true)
                {
                    b = false;
                    flag = true;
                    lastPos2 = path;
                    SubPath(path);
                    lastPos = path;
                    slave.SetActive(true);
                    Debug.Log("path :" + path);
                    startShort = true;
                    //Slave obj = new Slave();

                }
                if ((rightRay() > 6) && frontRay() > 13)
                    {
                        RegRightOpen();
                        startS = false;
                    }
                 else 
                 {
                     startS = true;
                     moveDir(dir, 1f,7);
                 }
                }
                else if (rightRay() > 6 || rightRay() == 0)
                {
                    d = 'r';
                    open = 1;
                    flag = true;
                    b = true;
                    path += 'R';
                }
                else
                {
                    flag = false;
                    changeDirection(setDir('e'));
                    path += 'B';
                }
            


        }


    }

}
