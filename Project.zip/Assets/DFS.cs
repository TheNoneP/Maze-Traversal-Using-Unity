﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DFS : MonoBehaviour
{
    class Node
    {
        public Node parentPointer = null;
        public Node leftChild = null;
        public Node middleChild = null;
        public Node rightChild = null;
        public char dirFromParent;
        public char dirInMaze;
        public int ID;
        public int NID;
        public bool isDiscovered;
        public bool isRoot;
    };
    int seqIter = 0, k = 0,k2=0,open=0,count=0;
    char preDir, tarDir, xX = 'a', yY = 'a';
    int index;
    Node root = new Node();
    Node preNode,targetNode;
    string preNodeToCPDir = "", CPToTargetDir = "";
    public static string path="";
    string preNodeToCPID = "", targetNodeToCPID = "";
    int nid = 1,ID=0;
    Queue<Node> Q= new Queue<Node>();
    int[] seqNo = new int[] { 1, 2, 3, 4, 5,6,7 };
    public char dir = 'L';
    bool lockFlag = true, isMoveing = true, lockFor = false, Goal = false;
    public static bool startShort =false;
    void changeDirection(char tem)
    {
        dir = tem;
    }
    char setDir(char tem)
    {
        if (tem != 'e' && tem !=' ')
        {
            if (dir == 'L')
            {
                if (tem == 'L')
                {
                    return 'D';
                }
                else
                {
                    return 'U';
                }
            }
            else if (dir == 'R')
            {
                if (tem == 'L')
                {
                    return 'U';
                }
                else
                {
                    return 'D';
                }
            }
            else if (dir == 'U')
            {
                if (tem == 'L')
                {
                    return 'L';
                }
                else
                {
                    return 'R';
                }
            }
            else if (dir == 'D')
            {
                if (tem == 'L')
                {
                    return 'R';
                }
                else
                {
                    return 'L';
                }
            }
        }
        if (tem == 'e')
        {
            if (dir == 'L')
            {
                return 'R';
            }
            else if (dir == 'R')
            {
                return 'L';
            }
            else if (dir == 'U')
            {
                return 'D';
            }
            else
            {
                return 'U';
            }
        }
        return dir;
    }

    void moveDir(char dir, float dis, int spd)
    {

        dis = 0.5f;
        if (dir == 'L')
        {

            transform.position = Vector3.MoveTowards(transform.position, transform.position - new Vector3(dis, 0f, 0f), 0.3f);

        }
        else if (dir == 'R')
        {

            transform.position = Vector3.MoveTowards(transform.position, transform.position + new Vector3(dis, 0f, 0f), 0.3f);
        }
        else if (dir == 'U')
        {
            transform.position = Vector3.MoveTowards(transform.position, transform.position + new Vector3(0f, 0f, dis), 0.3f);

        }
        else
        {


            transform.position = Vector3.MoveTowards(transform.position, transform.position - new Vector3(0f, 0f, dis), 0.3f);


        }
    }
    float leftRay()
    {
        RaycastHit hit;
        if (dir == 'L')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'R')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'U')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'D')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    float rightRay()
    {
        RaycastHit hit;
        if (dir == 'L')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'R')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'U')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'D')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    float frontRay()
    {
        RaycastHit hit;
        if (dir == 'L')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'R')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'U')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'D')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
           // Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    void drawDir()
    {
        RaycastHit hit;
        if (dir == 'L')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'R')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'U')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'D')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else hit = new RaycastHit();
        if (dir == 'L')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2));
        }
        else if (dir == 'R')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'U')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'D')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else hit = new RaycastHit();
        if (dir == 'L')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'R')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'U')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'D')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else hit = new RaycastHit();
    }
    void updateID()
    {
        ID++;
    }
    int assignID()
    {
        return ID;
    }
    int returnNID()
    {
        return nid++;
    }
    void initializeNode(Node node, char dirFromPar, char dirInMaz, bool isDis, Node lefChi, Node midChi, Node righChi, Node parPo, int ID, int nid)
    {
        node.dirFromParent = dirFromPar;
        node.dirInMaze = dirInMaz;
        node.isDiscovered = isDis;
        node.leftChild = lefChi;
        node.middleChild = midChi;
        node.rightChild = righChi;
        node.parentPointer = parPo;
        node.ID = ID;
        node.NID = nid;
    }
    void exploreChilds(Node node)
    {
        if (node.isDiscovered == false)
        {

            if (frontRay() > 3 && (rightRay() < 6 && rightRay() > 0) && ( leftRay() < 6 && leftRay() > 0) && lockFor == false)
            {
                moveDir(dir, 1f,7);
            }
            else
            {
                if (leftRay()>6 || leftRay()==0)
                {
                    Node tem1 = new Node();
                    initializeNode(tem1, 'L', 'L', false, null, null, null, node, assignID(), returnNID());
                    node.leftChild = tem1;
                    Q.Enqueue(tem1); 
                    // the below is forward child or right
                    if (frontRay()>10)
                    {
                        Node tem2 = new Node();
                        initializeNode(tem2, 'm', 'S', false, null, null, null, node, assignID(), returnNID());
                        node.middleChild = tem2;
                        Q.Enqueue(tem2);
                        //cout<<"two childs\n";
                    }
                    if (rightRay() > 6 ||rightRay() == 0)
                    {
                        Node tem3 = new Node();
                        initializeNode(tem3, 'R', 'R', false, null, null, null, node, assignID(), returnNID());
                        node.rightChild = tem3;
                        Q.Enqueue(tem3);
                        //cout<<"two childs\n";
                    }
                    updateID();
                }
                else if (rightRay() > 6 || rightRay() == 0)
                {
                    if (leftRay()> 6)
                    {
                        Node tem4 = new Node();
                        initializeNode(tem4, 'L', 'L', false, null, null, null, node, assignID(), returnNID());
                        node.leftChild = tem4;
                        Q.Enqueue(tem4);
                        //cout<<"two childs\n";
                    }
                    if (frontRay() > 10)
                    {
                        Node tem5 = new Node();
                        initializeNode(tem5, 'm', 'S', false, null, null, null, node, assignID(), returnNID());
                        node.middleChild = tem5;
                        Q.Enqueue(tem5);
                        //cout<<"two childs\n";
                    }// left child as front of left in maze
                    Node tem6 = new Node();
                    initializeNode(tem6, 'R', 'R', false, null, null, null, node, assignID(), returnNID());
                    node.rightChild = tem6;
                    Q.Enqueue(tem6);


                    updateID();
                }
                if(lockFor==false)
                changeDirection(setDir('e'));
                if (leftRay() > 6 || rightRay() > 6 || leftRay()==0 || rightRay()==0)
                {
                    Debug.Log("Backing");
                    lockFor = true;
                    moveDir(dir, 1f, 7);
                    
                }
                else
                {
                    changeDirection(setDir('e'));
                    seqIter++;
                    lockFor = false;
                }
            }
        }

    }
    int returnCommonNID(Queue<int> pre, Queue<int> tar)
    {
        int tem1, tem2, val=-1;
        Queue<int> hold=new Queue<int>();
        bool found = false;
        while (pre.Count != 0)
        {
            tem1 = pre.Dequeue();
            while (tar.Count != 0)
            {
                tem2 = tar.Dequeue();
                if (tem1 == tem2)
                {
                    val = tem1;
                    found = true;
                    break;
                }
                hold.Enqueue(tem2);
            }
            if (found == true)
            {
                break;
            }
            while (hold.Count != 0)
            {
                tar.Enqueue(hold.Dequeue());
            }            
        }
        return val;
    }

    int posOfCommon(int x, Queue<int> tem)
    {
        int count = -1;
        if (tem.Count == 1)
        {
            return 0;
        }
        else
        {
            count = 0;
            while (tem.Count != 0)
            {
                if (tem.Dequeue() == x)
                    break;
                count++;
            }
            return count;
        }
    }

    string returnCommonParent()
    {
        xX = 'a';
        yY = 'a';
        Queue<int> pre = new Queue<int>();
        Queue<int> tar = new Queue<int>();
        Queue<int> pre2 = new Queue<int>();
        Queue<int> tar2 = new Queue<int>();
        Node tt1, tt2;
        tt1 = preNode;
        tt2 = targetNode;
        while (tt1 != null)
        {
            pre.Enqueue(tt1.NID);

            preNodeToCPDir += tt1.dirInMaze;
            tt1 = tt1.parentPointer;
        }
        while (tt2 != null)
        {
            tar.Enqueue(tt2.NID);
            CPToTargetDir += tt2.dirInMaze;
            tt2 = tt2.parentPointer;

            //cout<<"entered !!!"<<endl;
        }
        foreach (int i in pre)
        {
            pre2.Enqueue(i);
            Debug.Log(i);
        }
        foreach (int i in tar)
        {
            tar2.Enqueue(i);
            Debug.Log(i);
        }
        int theVar = returnCommonNID(pre2, tar2);
        Debug.Log("the var : " + theVar);
        if (preNodeToCPDir.Length > 1)
        {
            preNodeToCPDir = preNodeToCPDir.Substring(0, posOfCommon(theVar, pre));
            if (preNodeToCPDir.Length >= 1)
                xX = preNodeToCPDir[preNodeToCPDir.Length - 1];
            else xX = 'a';
        }
        else if (preNodeToCPDir.Length <= 1 && preNodeToCPDir == "A")
        {
            preNodeToCPDir = "";
            xX = 'a';
        }
        else
        {
            xX = preNodeToCPDir[preNodeToCPDir.Length - 1];
        }
        if (CPToTargetDir.Length > 1)
        {
            CPToTargetDir = CPToTargetDir.Substring(0, posOfCommon(theVar, tar));
            if (CPToTargetDir.Length >= 1)
                yY = CPToTargetDir[CPToTargetDir.Length - 1];
            else yY = 'a';
        }
        else if (CPToTargetDir.Length <= 1 && CPToTargetDir == "A")
        {
            CPToTargetDir = "";
            yY = 'a';
        }
        else
        {
            yY = CPToTargetDir[CPToTargetDir.Length - 1];
        }
        Debug.Log("pre :" + preNodeToCPDir);
        Debug.Log("tar :" + CPToTargetDir);
        
        return "";
    }
    bool IsGoal2()
    {
        if (transform.position.x <= 199) { return true; }
        //else return false;
        else
        {
            return false;

        }
    }
    void oneStep(char d,char dIr)
    {
        if (IsGoal2() == false)
        {
            if (open == 2)
            {
                if (count++ > 10)
                {
                    count = 0;
                    open--;

                }
                moveDir(dir, 1f, 7);
            }
            else if (open == 1)
            {
                if (count == 0)
                    changeDirection(setDir(d));
                if (count++ > 16)
                {
                    count = 0;
                    open--;
                    isMoveing = true;
                    if (dIr == 'P')
                        k++;
                    else if (dIr == 'T')
                        k2++;
                }
                moveDir(dir, 1f, 8);
            }
        }
        else
        {
            targetNode.isDiscovered = true;
            Goal = true;
        }
        
    }
    string mapLastDirToParent()
    {
        char P = preNodeToCPDir[preNodeToCPDir.Length - 1];
        char T = CPToTargetDir[CPToTargetDir.Length - 1];
        if(P=='L')
        {
            if(T=='R')
            {
                preNodeToCPDir= preNodeToCPDir.Remove(preNodeToCPDir.Length - 1)+"S";
            }
            else
            {
                preNodeToCPDir = preNodeToCPDir.Remove(preNodeToCPDir.Length - 1) + "L";
            }
        }
        else if(P=='R')
        {
            if (T == 'L')
            {
                preNodeToCPDir = preNodeToCPDir.Remove(preNodeToCPDir.Length - 1) + "S";
            }
            else
            {
                preNodeToCPDir = preNodeToCPDir.Remove(preNodeToCPDir.Length - 1) + "R";
            }
        }
        else if(P=='S')
        {
            if (T == 'R')
            {
                preNodeToCPDir = preNodeToCPDir.Remove(preNodeToCPDir.Length - 1) + "L";
            }
            else
            {
                preNodeToCPDir = preNodeToCPDir.Remove(preNodeToCPDir.Length - 1) + "R";
            }
        }
        return preNodeToCPDir;
    }
void moveToCommonParent(string stt, char x, char y)
    {
        if (k < preNodeToCPDir.Length && preNodeToCPDir != "")
        {
            if (preNodeToCPDir != "")
            {
                if (x != y)
                {
                    Debug.Log("X != Y");
                    string st = stt;
                    string hold = "";
                    // reverse direction to DE
                    for (int i = 0; i < st.Length - 1; i++)
                    {
                        if (st[i] == 'L')
                        {
                            hold += 'R';
                        }
                        else if (st[i] == 'R')
                        {
                            hold += 'L';
                        }
                        else
                        {
                            hold += 'S';
                        }
                    }
                    preNodeToCPDir = mapLastDirToParent();
                    if(preNodeToCPDir.Length>1)
                    preNodeToCPDir = hold + preNodeToCPDir.Remove(0, preNodeToCPDir.Length - 1);
                    Debug.Log("stt : " + preNodeToCPDir);
                    changeDirection(setDir('e'));
                    xX = 't';
                    yY = 't';
                }
                else if (stt[k] == 'L')
                {
                    if (leftRay() < 6 && leftRay()>0 && isMoveing == true)
                    {
                        moveDir(dir, 1f, 7);
                    }
                    else
                    {
                        if (isMoveing == true)
                        {
                            isMoveing = false;
                            open = 2;
                        }
                        else if (isMoveing == false)
                        {
                            oneStep('L', 'P');
                        }

                    }

                }
                else if (stt[k] == 'R')
                {
                    if (rightRay() < 6 && rightRay()>0 && isMoveing == true)
                    {
                        moveDir(dir, 1f, 7);
                    }
                    else
                    {
                        if (isMoveing == true)
                        {
                            isMoveing = false;
                            open = 2;
                        }
                        else if (isMoveing == false)
                        {
                            oneStep('R', 'P');
                        }


                    }
                }
                else
                {
                    if (leftRay() < 6 && rightRay() < 6 && frontRay() > 6 && isMoveing == true)
                    {
                        moveDir(dir, 1f, 7);
                    }
                    else
                    {

                        if (isMoveing == true)
                        {
                            isMoveing = false;
                            open = 2;
                        }
                        else if (isMoveing == false)
                        {
                            oneStep(' ', 'P');
                        }


                    }
                }
                 
            }
        }
        else
        {
            if (preNodeToCPDir.Length == 1)
                k2 = 1;
            else if (preNodeToCPDir.Length > 1)
                k2 = 1;
            else k2 = 0;
            seqIter++;
           
        }
        
    }

    void moveToTarget(string stt)
    {
        if (k2 < CPToTargetDir.Length && CPToTargetDir != "")
        {
            if (stt[CPToTargetDir.Length - 1 - k2] == 'L')
            {
                if (leftRay() < 6 && leftRay()>0&& isMoveing == true)
                {
                    moveDir(dir, 1f, 7);
                }
                else
                {
                    if (isMoveing == true)
                    {
                        isMoveing = false;
                        open = 2;
                    }
                    else if (isMoveing == false)
                    {
                        oneStep('L', 'T');
                    }

                }

            }
            else if (stt[CPToTargetDir.Length - 1 - k2] == 'R')
            {
                if (rightRay() < 6 && rightRay()>0 && isMoveing == true)
                {
                    moveDir(dir, 1f, 7);
                }
                else
                {
                    if (isMoveing == true)
                    {
                        isMoveing = false;
                        open = 2;
                    }
                    else if (isMoveing == false)
                    {
                        oneStep('R', 'T');
                    }


                }
            }
            else
            {
                if (leftRay() < 6 && rightRay() < 6 && frontRay() > 6 && isMoveing == true)
                {
                    moveDir(dir, 1f, 7);
                }
                else
                {

                    if (isMoveing == true)
                    {
                        isMoveing = false;
                        open = 2;
                    }
                    else if (isMoveing == false)
                    {
                        oneStep(' ', 'T');
                    }


                }
            }
        }
        else
        {
            seqIter++;
            lockFlag = true;
        }
        
    }
    void initializeRoot()
    {
        initializeNode(root, 'A', 'A', false, null, null, null, null, assignID(), 0);
        updateID();
        Q.Enqueue(root);
        root.isRoot = true;
        preNode = root;
    }
    
    private void Start()
    {
        initializeRoot();
    }
    private void Update()
    {
        drawDir();
        if(IsGoal2()==true)
        {
            targetNode.isDiscovered = true;
            Goal = true;
        }
        if (Goal == true && seqIter !=6)
        {
            Node n;
            Queue<Node> que = new Queue<Node>();
            que.Enqueue(root);
            n = que.Dequeue();
            while(n.isDiscovered==false)
            {
                if (n.leftChild != null)
                    que.Enqueue(n.leftChild);
                if (n.middleChild != null)
                    que.Enqueue(n.middleChild);
                if (n.rightChild != null)
                    que.Enqueue(n.rightChild);
                n = que.Dequeue();

            }
            string direc = "";
            while(n!=null)
            {
                direc += n.dirInMaze;
                n = n.parentPointer;
            }
            Debug.Log("shortest : " + direc);
            for(int i=direc.Length-2;i>=0;i--)
                path += direc[i];
            Debug.Log("shortest : " + path);
            startShort = true;
            Goal = false;
            seqIter = 6;
            
        }
        else if (seqNo[seqIter] == 1 )
        {
            Debug.Log("in 0");
            if (Q.Count != 0)
            {
                targetNode = Q.Dequeue();
                seqIter++;
            }

        }
        else if (seqNo[seqIter] == 2)
        {
            Debug.Log("in 1");
            returnCommonParent();
            seqIter++;

        }
        else if (seqNo[seqIter] == 3)
        {
            //return to common parent
            moveToCommonParent(preNodeToCPDir, xX, yY);
            Debug.Log("in 2");
        }
        else if (seqNo[seqIter] == 4)
        {
            Debug.Log("in 3");
            //move to target
            moveToTarget(CPToTargetDir);
           
        }
        else if (seqNo[seqIter] == 5)
        {
            //explore childs
            exploreChilds(targetNode);
            Debug.Log("in 4");


        }
        else if (seqNo[seqIter] == 6)
        {
            Debug.Log("in 6");
            Debug.Log(Q.Count);
            preNodeToCPDir = "";
            preNodeToCPID = "";
            CPToTargetDir = "";
            targetNodeToCPID = "";
            preNode = targetNode;
            k = 0;

            seqIter = 0;

        }

    }

}

