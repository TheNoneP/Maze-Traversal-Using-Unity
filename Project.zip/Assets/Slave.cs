﻿using UnityEngine;
public class Slave : MonoBehaviour
{
    private bool startS = true;
    private int open, it = 0;
    private bool b = false, flag = false;
    private char d;
    private bool fg = false;
    public char dir = 'l';
    private int count = 0;

    void moveDir(char dir, float dis,int spd)
    {

        dis = 0.5f;   
        if (dir == 'l')
        {

            transform.position = Vector3.MoveTowards(transform.position, transform.position - new Vector3(dis, 0f, 0f), 0.3f);

        }
        else if (dir == 'r')
        {

            transform.position = Vector3.MoveTowards(transform.position, transform.position + new Vector3(dis, 0f, 0f), 0.3f);
        }
        else if (dir == 'u')
        {
            transform.position = Vector3.MoveTowards(transform.position, transform.position + new Vector3(0f, 0f, dis), 0.3f);

        }
        else
        {


            transform.position = Vector3.MoveTowards(transform.position, transform.position - new Vector3(0f, 0f, dis), 0.3f);


        }
    }

    void oneStepMovement()
    {
        moveDir(dir, 0.9f,4);
    }

    float leftRay()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    float rightRay()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    float frontRay()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(hit.distance, 0f, 0f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            //Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, hit.distance));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            //Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, hit.distance));
        }
        else hit = new RaycastHit();
        return hit.distance;
    }
    void drawDir()
    {
        RaycastHit hit;
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else hit = new RaycastHit();
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else hit = new RaycastHit();
        if (dir == 'l')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'r')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(2f, 0f, 0f));
        }
        else if (dir == 'u')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit);
            Debug.DrawLine(transform.position, transform.position + new Vector3(0f, 0f, 2f));
        }
        else if (dir == 'd')
        {
            Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit);
            Debug.DrawLine(transform.position, transform.position - new Vector3(0f, 0f, 2f));
        }
        else hit = new RaycastHit();
    }
    void changeDirection(char tem)
    {
        dir = tem;
    }
    char setDir(char tem)
    {
        if (tem != ' ')
        {
            if (tem != 'e')
            {
                if (dir == 'l')
                {
                    if (tem == 'l')
                    {
                        return 'd';
                    }
                    else
                    {
                        return 'u';
                    }
                }
                else if (dir == 'r')
                {
                    if (tem == 'l')
                    {
                        return 'u';
                    }
                    else
                    {
                        return 'd';
                    }
                }
                else if (dir == 'u')
                {
                    if (tem == 'l')
                    {
                        return 'l';
                    }
                    else
                    {
                        return 'r';
                    }
                }
                else if (dir == 'd')
                {
                    if (tem == 'l')
                    {
                        return 'r';
                    }
                    else
                    {
                        return 'l';
                    }
                }
            }
            if (tem == 'e')
            {
                if (dir == 'l')
                {
                    return 'r';
                }
                else if (dir == 'r')
                {
                    return 'l';
                }
                else if (dir == 'u')
                {
                    return 'd';
                }
                else
                {
                    return 'u';
                }
            }

        }
        return dir;
    }
    void moveSlaveToShortesPath()
    {

        if (Movement.path[it] == 'B')
        {
            Debug.Log("in B");
            changeDirection(setDir('e'));
            it++;
        }
        else if (Movement.path[it] == 'L')
        {
            Debug.Log("in l");
            if (leftRay() < 6 && leftRay() > 0)
                moveDir(dir, 1f, 7);
            else
            {
                d = 'l';
                open = 2;
                flag = true;
                b = true; it++;
            }

        }
        else if (Movement.path[it] == 'R')
        {
            Debug.Log("in r");
            if (rightRay() < 6 && rightRay() > 0)
                moveDir(dir, 1f, 7);
            else
            {
                d = 'r';
                open = 2;
                flag = true;
                b = true; it++;
            }
        }
        else if (Movement.path[it] == 'S')
        {
            Debug.Log("in S");
            if ((rightRay() < 6 || rightRay() == 0) && (leftRay() < 12 || leftRay() == 0))
            {
                moveDir(dir, 1f,7);
            }
            else
            {
                flag = true;
                open = 2;
                d = ' ';
                it++;
            }
        }

    }
    bool IsGoal()
    {
        if (transform.position.x <= 199) { return true; }
        //else return false;
        else
        {
            return false;

        }
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is cal led once per frame
    void Update()
    {
        drawDir();
        if (flag == true)
        {
            if (open == 2)
            {
                if (count++ > 10)
                {
                    count = 0;
                    open--;

                }
                oneStepMovement();
            }
            else if (open == 1)
            {
                if (count == 0)
                    changeDirection(setDir(d));
                if (count++ > 16)
                {
                    count = 0;
                    open--;
                    flag = false;
                }
                oneStepMovement();
            }
            else if (open <= 0)
            {

                open = 0;
                flag = false;

            }
        }

        if (flag == false && Movement.startShort == true && it < Movement.path.Length)
        {
            Debug.Log("in updated slave");
            moveSlaveToShortesPath();


        }
        else if (Movement.startShort == true && IsGoal() == false && it >= Movement.path.Length && open==0)
            moveDir(dir, 0.1f,7);


    }
}
