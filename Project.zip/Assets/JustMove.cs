﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JustMove 
{
    public GameObject GO;
    int count = 0;
    public void move()
    {
        
            
                GO.transform.position += new Vector3(0F, 0F, 0.1F);
            //    start = Time.time;
                count++;
            
        //    if (count > 50) break;
        
    }
}
